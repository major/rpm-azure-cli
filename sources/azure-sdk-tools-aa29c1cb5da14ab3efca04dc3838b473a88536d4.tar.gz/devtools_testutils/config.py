TEST_SETTING_FILENAME = "testsettings_local.cfg"
